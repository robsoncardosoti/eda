module.exports.SEED  = 'que-haces-mirando-esto?';





