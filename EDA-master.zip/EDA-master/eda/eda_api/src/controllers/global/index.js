module.exports = {
    ds: require('./data-source-controller'),
    search: require('./search-controller'),
    upload: require('./upload-controller')
}