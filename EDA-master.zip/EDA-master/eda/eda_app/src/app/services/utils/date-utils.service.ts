import * as _ from 'lodash';
import * as moment_ from 'moment';
import { Injectable } from '@angular/core';
// const moment = moment_;

@Injectable()
export class DateUtils {

    getDateFormatApp(date: any, ignoreTimeZone = true) {
        
    }

}