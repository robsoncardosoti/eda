export class EdaPageDialog {
    display: boolean;
    title: string;
    style: {} = {};
    hide: () => void = () => {};
}
